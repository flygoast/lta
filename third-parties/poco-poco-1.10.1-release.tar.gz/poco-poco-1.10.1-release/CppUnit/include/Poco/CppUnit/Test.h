//
// Test.h
//


#ifndef Poco_CppUnit_Test_INCLUDED
#define Poco_CppUnit_Test_INCLUDED


#include "CppUnit/Test.h"

#endif // Poco_CppUnit_Test_INCLUDED
