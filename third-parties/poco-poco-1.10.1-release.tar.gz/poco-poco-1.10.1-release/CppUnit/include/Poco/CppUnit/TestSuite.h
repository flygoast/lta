//
// TestSuite.h
//


#ifndef Poco_CppUnit_TestSuite_INCLUDED
#define Poco_CppUnit_TestSuite_INCLUDED

#include "CppUnit/TestSuite.h"

#endif // Poco_CppUnit_TestSuite_INCLUDED
